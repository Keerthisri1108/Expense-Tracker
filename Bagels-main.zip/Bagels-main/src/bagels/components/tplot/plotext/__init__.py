"""Wrapper module for the main Plotext module.

Designed to help type hint the public symbols in the module. See also the
accompanying pyi file for the types.
"""

from plotext import *  # noqa
